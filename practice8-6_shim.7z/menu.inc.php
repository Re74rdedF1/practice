            <nav>
                <ul>
                    <li><a href="#"> О моей учёбе </a></li>
                    <li><a href="#"> Моё портфолию </a></li>
                    <li><a href="#"> мои статьи </a></li>
                    <li><a href="#"> Ссылки </a></li>
                    <li><a href="#"> Контакты </a></li>
                </ul>    
            </nav>