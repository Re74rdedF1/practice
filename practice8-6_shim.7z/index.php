

<?php 
 $p = 'Приветствую гостя на моей странице!';
?>

<?php 
 $name = 'Максим';
 $surname = 'Шиманов';
 $city = 'Москва';
 $age = 22;
?>


<?php
include 'main.php';
?>

