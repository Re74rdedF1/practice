<div class="footer">
            <h2>Я изучил основы PHP</h2>
        </div>